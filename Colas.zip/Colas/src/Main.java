public class Main {

    public static void main(String[] args) {
        new Execute().menu(); // Llamada al metodo que ejecuta al menu
    }
}
